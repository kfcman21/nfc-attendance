// Rs232c06Dlg.cpp : implementation file
//

#include "stdafx.h"
#include "Rs232c06.h"
#include "Rs232c06Dlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRs232c06Dlg dialog

CRs232c06Dlg::CRs232c06Dlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRs232c06Dlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRs232c06Dlg)
	m_strEdt_RvcData = _T("");
	m_strEdt_SendData = _T("");
	m_strCbo_Port = _T("");
	m_strCbo_Baud = _T("");
	m_strEdt_SendHis = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_nPbufpt = 0;
	m_nRbufpt = 0;
	m_nPbufLpt = m_nRbufLpt = 0;
}

void CRs232c06Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRs232c06Dlg)
	DDX_Control(pDX, IDC_EDT_SENDHIS, m_ctlEdt_SendHis);
	DDX_Control(pDX, IDC_EDT_RVCDATA, m_ctlEdt_RcvData);
	DDX_Control(pDX, IDC_COB_STOP, m_ctlCob_Stop);
	DDX_Control(pDX, IDC_COB_PTY, m_ctlCob_Pty);
	DDX_Control(pDX, IDC_COB_PORT, m_ctlCob_Port);
	DDX_Control(pDX, IDC_COB_DATA, m_ctlCob_Data);
	DDX_Control(pDX, IDC_COB_BAUD, m_ctlCob_Baud);
	DDX_Text(pDX, IDC_EDT_RVCDATA, m_strEdt_RvcData);
	DDX_Text(pDX, IDC_EDT_SENDDATA, m_strEdt_SendData);
	DDX_CBString(pDX, IDC_COB_PORT, m_strCbo_Port);
	DDX_CBString(pDX, IDC_COB_BAUD, m_strCbo_Baud);
//	DDX_Text(pDX, IDC_EDIT1, m_aaa);
	DDX_Text(pDX, IDC_EDT_SENDHIS, m_strEdt_SendHis);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRs232c06Dlg, CDialog)
	//{{AFX_MSG_MAP(CRs232c06Dlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_LBUTTONDOWN()
	ON_BN_CLICKED(IDC_BTN_EXIT, OnBtnExit)
	ON_BN_CLICKED(IDC_BTN_CONNECT, OnBtnConnect)
	ON_BN_CLICKED(IDC_BTN_SENDING, OnBtnSending)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BTN_MPCLEAR, OnBtnMpclear)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_RECEIVEDATA,OnRcvMessage)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRs232c06Dlg message handlers

BOOL CRs232c06Dlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	// Add "About..." menu item to system menu.
	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//��Ʈ���� �ں��ڽ��� �� �������� �ִ´�.
	m_ctlCob_Baud.AddString("9600");
	m_ctlCob_Baud.AddString("14400");
	m_ctlCob_Baud.AddString("19200");
	m_ctlCob_Baud.AddString("38400");
	m_ctlCob_Baud.AddString("57600");

	m_ctlCob_Port.AddString("COM1");
	m_ctlCob_Port.AddString("COM2");

	m_ctlCob_Data.AddString("4");
	m_ctlCob_Data.AddString("5");
	m_ctlCob_Data.AddString("6");
	m_ctlCob_Data.AddString("7");
	m_ctlCob_Data.AddString("8");

	m_ctlCob_Pty.AddString("¦��");
	m_ctlCob_Pty.AddString("Ȧ��");

	m_ctlCob_Stop.AddString("1");
	m_ctlCob_Stop.AddString("1.5");
	m_ctlCob_Stop.AddString("2");
	/////////////////////////////////////////////
	m_ctlCob_Baud.SetCurSel(3);
	m_ctlCob_Port.SetCurSel(0);
	m_ctlCob_Data.SetCurSel(4);
	m_ctlCob_Pty.SetCurSel(0);
	m_ctlCob_Stop.SetCurSel(0);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRs232c06Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRs232c06Dlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
		
	}
	else
	{
		//######### ���ۿ��� �� ��ǥ�� �о� �鿩 �ٽ� �׷��ش�. #######
		CClientDC cdc(this);
		CPoint p;
		int pt;
		pt = m_nPbufLpt;//x�� �о�鸱 �����ּҸ� ���� �װ��� ���� ���� ���ۿ� �ִ� ������ �����´�.
		while(m_nPbufpt != pt){//�������� ���콺 ��ǥ�� ���� �׷��ش�.
			p.x = m_nPosbuff[0][pt];
			p.y = m_nPosbuff[1][pt];
			DrawCross(&cdc, p);
			pt++;
			if(pt >= MAX_BUF)
				pt = 0;
		}
		pt = m_nRbufLpt;
		while(m_nRbufpt != pt){//��ǥ�����͸� ���� ���콺 ��ǥ�� ����ش�.
			p.x = m_nRcvPosbuff[0][pt];
			p.y = m_nRcvPosbuff[1][pt];
			DrawCross(&cdc, p);
			pt++;
			if(pt >= MAX_BUF)
				pt = 0;
		}
		
		//#############################################################
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRs232c06Dlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


void CRs232c06Dlg::OnBtnExit() 
{
	// TODO: Add your control notification handler code here
	if(m_Com.fCnt)
		m_Com.CloseConnection();
	DestroyWindow();
}

void CRs232c06Dlg::OnBtnConnect() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	if(m_Com.fCnt){//������ ���ִ� ����
		m_Com.CloseConnection();
		m_ctlEdt_RcvData.ReplaceSel("DeConnect\r\n");
		SetDlgItemText(IDC_BTN_CONNECT,"Connect");
		m_ctlCob_Port.EnableWindow(TRUE);
		m_ctlCob_Baud.EnableWindow(TRUE);
		m_ctlCob_Data.EnableWindow(TRUE);
		m_ctlCob_Pty.EnableWindow(TRUE);
		m_ctlCob_Stop.EnableWindow(TRUE);
	}
	else{
		int s[4];
		sscanf(m_strCbo_Baud,"%d",&s[0]);// = m_Baud[m_ctlBaud.GetCurSel()];
		s[1] = m_ctlCob_Data.GetCurSel()+4;
		s[2] = m_ctlCob_Pty.GetCurSel();
		s[3] = m_ctlCob_Stop.GetCurSel();
		//��Ʈ����
		m_Com.SetComPort(m_strCbo_Port,s[0],s[1],s[2],s[3]);//com,bps,data,parity,stop
		if(m_Com.OpenComPort()){//CreateCommInfo()){
			m_Com.SetHwnd(this->m_hWnd);//�޼����� ����� �ڵ鷯�� ����
			m_ctlEdt_RcvData.ReplaceSel("Connect OK\r\n");
			SetDlgItemText(IDC_BTN_CONNECT,"Deconnect");
			m_ctlCob_Port.EnableWindow(FALSE);
			m_ctlCob_Baud.EnableWindow(FALSE);
			m_ctlCob_Data.EnableWindow(FALSE);
			m_ctlCob_Pty.EnableWindow(FALSE);
			m_ctlCob_Stop.EnableWindow(FALSE);
			GetDlgItem(IDC_EDT_SENDDATA)->SetFocus();
		}
		else{
			m_ctlEdt_RcvData.ReplaceSel("Connect Error!! \r\n");
		}

	}
}

void CRs232c06Dlg::OnBtnSending() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	Data SendData;
	CString x;
	DWORD Size;
	SendData.chk = 1;
	int len = m_strEdt_SendData.GetLength();
	if(len < MAX_STR-1)//������ �ִ� ������ ������ �˻��Ѵ�. -1�� �ǳ��� �ι��ڰ� ���� �ϱ⶧���̴�.
	{
		for (int i=0 ;i < m_strEdt_SendData.GetLength();i++){
				SendData.Fdata[i] = m_strEdt_SendData[i];
		}
		m_strEdt_SendData = _T("");
		UpdateData(FALSE);
		SendData.Fdata[i] = ASC_NUL;//���� ���� �ǳ��� �ι��ڸ� �־��ش�.
		SendData.Ldata[0] = ASC_NUL;
		Size = sizeof(SendData);
		m_Com.WriteCommBlock((LPCVOID)&SendData,Size);
		x.Format("%s\r\n",SendData.Fdata);
		m_ctlEdt_SendHis.ReplaceSel(x);
	}
	else {
		x.Format("������ �� �ִ� �ִ� ������ ������ %d�� �Դϴ�.",MAX_STR-1);
		AfxMessageBox(x);
	}
	
}

//���� ���콺 ��ư�� ���������� ���콺�� ��ǥ�� �����Ѵ�.
void CRs232c06Dlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default

	if((362 <= point.x) && (point.x <= 688)){
		if((30 <= point.y) && (point.y <= 294)){
			if(!m_Com.fCnt)
				AfxMessageBox("Com port�� ������ �ȵǾ����ϴ�. �����Ŀ� �ϼ���");
			else{
				CClientDC dc(this);
				CString px,py;
				Data SendData;
				px.Format("%d",point.x);
				py.Format("%d",point.y);
				DWORD Size;
				SendData.chk = 0;
				for (int i=0 ;i < px.GetLength();i++)
					SendData.Fdata[i] = px[i];
				SendData.Fdata[i] = '\0';
				for(i=0;i<py.GetLength();i++)
					SendData.Ldata[i] = py[i];
				SendData.Ldata[i] = '\0';
				Size = sizeof(SendData);//������ ������(����ü)��ũ�⸦ ���Ѵ�.
				Size = m_Com.WriteCommBlock((LPCVOID)&SendData,Size);//�����͸� ����
				px.Format("x : %d, y : %d\r\n",point.x,point.y);
				DrawCross(&dc,point);
				SaveBuffer(0,point);
				m_ctlEdt_SendHis.ReplaceSel(px);
			}
		}
	}
	CDialog::OnLButtonDown(nFlags, point);
}


void CRs232c06Dlg::OnRcvMessage(WPARAM wParam, LPARAM lParam){
	Data RData;
	CString Temp;
	memcpy((void *)&RData,m_Com.RcvData,sizeof(Data));	
	int x,y;
	x=y=0;
	Temp = _T("");
	if(RData.chk){//�ؽ�Ʈ �Է��� ��������
		CString Msg=_T("");
		Temp = RData.Fdata;
		
		while(RData.Fdata[y]){//NULL���� ���ö� ���� ������ ����.
			Msg += RData.Fdata[y];
			y++;
		}
		Msg += "\r\n";
		m_ctlEdt_RcvData.ReplaceSel(Msg);
	}
	else{//���콺���������
		CClientDC dc(this);
		CPoint point;
		sscanf(RData.Fdata,"%d",&x);
		sscanf(RData.Ldata,"%d",&y);
		Temp.Format("X : %d, Y : %d\r\n",x,y);
		m_ctlEdt_RcvData.ReplaceSel(Temp);
		point.x = x;
		point.y = y;
		DrawCross(&dc,point);
		SaveBuffer(0,point);
	}		
}

void CRs232c06Dlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_strEdt_SendHis = _T("");
	UpdateData(FALSE);
}

void CRs232c06Dlg::OnButton2() 
{
	// TODO: Add your control notification handler code here
	UpdateData(TRUE);
	m_strEdt_RvcData = _T("");
	UpdateData(FALSE);
}


void CRs232c06Dlg::DrawCross(CDC *pDC, CPoint point)
{
	pDC->MoveTo(point.x-5,point.y-5);
	pDC->LineTo(point.x+5,point.y+5);
	pDC->MoveTo(point.x-5,point.y+5);
	pDC->LineTo(point.x+5,point.y-5);
}

void CRs232c06Dlg::SaveBuffer(char type,CPoint point)
{
	if(type){//���� ���� ���� ���콺 ��ǥ�� ����Ѵ�.
		m_nPosbuff[0][m_nPbufpt] = point.x;
		m_nPosbuff[1][m_nPbufpt] = point.y;
		m_nPbufpt++;//������ �ּҸ� �Ѱ� ���� ��Ų��.
		if(m_nPbufpt >= MAX_BUF)//���콺 ��ǥ�� ���۰� ��á����..
		 		m_nPbufpt = 0;
		if(m_nPbufLpt == m_nPbufpt){
			m_nPbufLpt++;//�о�鸱 �ּҸ� �Ѱ� ���� ��Ų��.
			if(m_nPbufLpt >= MAX_BUF)
				m_nPbufLpt = 0;
		}
	}
	else{//���ŵ� �������� ���콺 ��ǥ�� ����Ѵ�.
		m_nRcvPosbuff[0][m_nRbufpt] = point.x;
		m_nRcvPosbuff[1][m_nRbufpt] = point.y;
		m_nRbufpt++;//������ �ּҸ� �Ѱ� ���� ��Ų��.
		if(m_nRbufpt >= MAX_BUF)//���콺 ��ǥ�� ���۰� ��á����..
		 		m_nRbufpt = 0;
		if(m_nRbufLpt == m_nRbufpt){
			m_nRbufLpt++;//�о�鸱 �ּҸ� �Ѱ� ���� ��Ų��.
			if(m_nRbufLpt >= MAX_BUF)
				m_nRbufLpt = 0;
		}
	}
}

void CRs232c06Dlg::OnBtnMpclear() 
{
	// TODO: Add your control notification handler code here
	m_nRbufLpt = m_nRbufpt = 0;
	m_nPbufLpt = m_nPbufpt = 0;
	Invalidate();
	OnPaint();
}

BOOL CRs232c06Dlg::PreTranslateMessage(MSG* pMsg) 
{
	// TODO: Add your specialized code here and/or call the base class
	if (pMsg->hwnd == ((CWnd*)GetDlgItem(IDC_EDT_SENDDATA))->GetSafeHwnd())
	{
		if (pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN){
			OnBtnSending();
			return TRUE;
		}
	}
	return CDialog::PreTranslateMessage(pMsg);
}
