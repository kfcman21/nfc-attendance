; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CRs232c06Dlg
LastTemplate=CSocket
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Rs232c06.h"

ClassCount=5
Class1=CRs232c06App
Class2=CRs232c06Dlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Class4=CSo
Class5=CCom
Resource3=IDD_RS232C06_DIALOG

[CLS:CRs232c06App]
Type=0
HeaderFile=Rs232c06.h
ImplementationFile=Rs232c06.cpp
Filter=N
LastObject=CRs232c06App

[CLS:CRs232c06Dlg]
Type=0
HeaderFile=Rs232c06Dlg.h
ImplementationFile=Rs232c06Dlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=CRs232c06Dlg

[CLS:CAboutDlg]
Type=0
HeaderFile=Rs232c06Dlg.h
ImplementationFile=Rs232c06Dlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_RS232C06_DIALOG]
Type=1
Class=CRs232c06Dlg
ControlCount=23
Control1=IDC_BTN_CONNECT,button,1342242816
Control2=IDC_BTN_SENDING,button,1342242816
Control3=IDC_EDT_SENDDATA,edit,1350631552
Control4=IDC_COB_PORT,combobox,1344339970
Control5=IDC_COB_BAUD,combobox,1344339970
Control6=IDC_COB_DATA,combobox,1344339970
Control7=IDC_COB_PTY,combobox,1344339970
Control8=IDC_COB_STOP,combobox,1344339970
Control9=IDC_BUTTON1,button,1342242816
Control10=IDC_BUTTON2,button,1342242816
Control11=IDC_BTN_MPCLEAR,button,1342242816
Control12=IDC_BTN_EXIT,button,1342242816
Control13=IDC_EDT_SENDHIS,edit,1350633668
Control14=IDC_STATIC,static,1342308352
Control15=IDC_STATIC,button,1342178055
Control16=IDC_STATIC,static,1342308352
Control17=IDC_STATIC,static,1342308352
Control18=IDC_STATIC,static,1342308352
Control19=IDC_STATIC,static,1342308352
Control20=IDC_STATIC,static,1342308352
Control21=IDC_EDT_RVCDATA,edit,1350633668
Control22=IDC_STATIC,static,1342308352
Control23=IDC_STATIC,static,1342308352

[CLS:CSo]
Type=0
HeaderFile=So.h
ImplementationFile=So.cpp
BaseClass=CObecjt
Filter=N
LastObject=CSo
VirtualFilter=uq

[CLS:CCom]
Type=0
HeaderFile=Com10.h
ImplementationFile=Com10.cpp
BaseClass=CSocket
Filter=N
LastObject=CCom

