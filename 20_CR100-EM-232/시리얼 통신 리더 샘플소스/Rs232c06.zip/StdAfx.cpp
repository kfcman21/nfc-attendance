// stdafx.cpp : source file that includes just the standard includes
//	Rs232c06.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



