// Rs232c06.h : main header file for the RS232C06 application
//

#if !defined(AFX_RS232C06_H__12313368_D301_4897_89B8_449D78BFA663__INCLUDED_)
#define AFX_RS232C06_H__12313368_D301_4897_89B8_449D78BFA663__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CRs232c06App:
// See Rs232c06.cpp for the implementation of this class
//

class CRs232c06App : public CWinApp
{
public:
	CRs232c06App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRs232c06App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRs232c06App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RS232C06_H__12313368_D301_4897_89B8_449D78BFA663__INCLUDED_)
