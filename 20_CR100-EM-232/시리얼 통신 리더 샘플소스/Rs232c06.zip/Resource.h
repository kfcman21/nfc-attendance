//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Rs232c06.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RS232C06_DIALOG             102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_EDT_SENDHIS                 1000
#define IDC_EDT_SENDDATA                1001
#define IDC_COB_PORT                    1002
#define IDC_COB_BAUD                    1003
#define IDC_COB_DATA                    1004
#define IDC_COB_PTY                     1005
#define IDC_COB_STOP                    1006
#define IDC_BTN_CONNECT                 1007
#define IDC_EDT_RVCDATA                 1008
#define IDC_BTN_SENDING                 1009
#define IDC_BTN_EXIT                    1010
#define IDC_EDIT1                       1011
#define IDC_BUTTON1                     1012
#define IDC_BUTTON2                     1013
#define IDC_BTN_MPCLEAR                 1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
