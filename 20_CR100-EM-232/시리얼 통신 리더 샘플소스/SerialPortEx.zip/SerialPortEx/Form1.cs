﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Threading;

namespace SerialPortEx
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private int[] m_iBaudRate = { 110, 300, 600, 1200, 2400, 4800, 9600, 14400, 19200, 
                                      38400, 56000, 57600, 115200, 128000, 256000 };

        private string[] m_strParity = { "None", "Odd", "Even", "Mark", "Space" };

        private string[] m_strStopBits = { "None", "One", "Tow", "OnePointFive" };

        private Thread m_readThread;
        private static bool m_Stop;
        private static AutoResetEvent m_StopCompletionEvent = new AutoResetEvent(false);



        // 스레드에서 UI 컨트롤을 접근하기 위한 delegate 함수 선언및 정의 
        delegate void ListRecCallback(string strtext);
        private void RecListAdd(string strRecData)
        {
            recList.Items.Add(strRecData);
        }
        private void DelegateRecListAdd(string strRecData)
        {
            this.Invoke(new ListRecCallback(RecListAdd), strRecData);
        }
        
                       
        private void Form1_Load(object sender, EventArgs e)
        {
            this.Width = 800;
            this.Height = 480;
            this.TopMost = true;

            // 시리얼 포트 설정
            radCom3.Checked = true;

            for (int i = 0; i < m_iBaudRate.Length; i++)
            {
                combBaudRate.Items.Add(m_iBaudRate[i].ToString());
            }
            combBaudRate.SelectedIndex = 6;


            for (int i = 0; i < m_strParity.Length; i++)
            {
                combParity.Items.Add(m_strParity[i]);
            }
            combParity.SelectedIndex = 0;

            txtDataBits.Text = "8";

            for(int i = 0; i < m_strStopBits.Length; i++)
            {
                combStop.Items.Add(m_strStopBits[i]);
            }
            combStop.SelectedIndex = 1;

            txtSendData.Text = "This is a test message";
        }

        private void butExit_Click(object sender, EventArgs e)
        {
            SerialPortClose();

            Application.Exit();
        }

        private void butOpen_Click(object sender, EventArgs e)
        {
            if (radCom1.Checked == true)
            {
                serialPort1.PortName = "COM1";
            }
            else if (radCom2.Checked == true)
            {
                serialPort1.PortName = "COM2";
            }
            else if (radCom3.Checked = true)
            {
                serialPort1.PortName = "COM3";
            }

            serialPort1.BaudRate = Convert.ToInt32(combBaudRate.SelectedItem);

            switch (combParity.SelectedIndex)
            {
                case 0:
                    serialPort1.Parity = System.IO.Ports.Parity.None;
                    break;
                case 1:
                    serialPort1.Parity = System.IO.Ports.Parity.Odd;
                    break;
                case 2:
                    serialPort1.Parity = System.IO.Ports.Parity.Even;
                    break;
                case 3:
                    serialPort1.Parity = System.IO.Ports.Parity.Mark;
                    break;
                case 4:
                    serialPort1.Parity = System.IO.Ports.Parity.Space;
                    break;
            }


            serialPort1.DataBits = Convert.ToInt32(txtDataBits.Text);


            switch (combStop.SelectedIndex)
            {
                case 0:
                    serialPort1.StopBits = System.IO.Ports.StopBits.None;
                    break;
                case 1:
                    serialPort1.StopBits = System.IO.Ports.StopBits.One;
                    break;
                case 2:
                    serialPort1.StopBits = System.IO.Ports.StopBits.Two;
                    break;
                case 3:
                    serialPort1.StopBits = System.IO.Ports.StopBits.OnePointFive;
                    break;
            }

            serialPort1.ReadTimeout = 500;

            serialPort1.Open();

            // 수신 스레드 시작
            m_readThread = new Thread(new ThreadStart(ComPortReadFunc));
            m_readThread.Start();

        }


        // Client연결 및 수신 스래드 함수
        private void ComPortReadFunc()
        {
            int iRecCnt = 0;
            string strRecData;
            byte[] recBuff = new byte[serialPort1.ReadBufferSize];
                    
            m_Stop = false;
            int i = 0;
                       
            try
            {
                while (true)
                {
                    // 수신데이터를 읽어온다.
                    //iRecCnt = serialPort1.Read(recBuff, 0, 1000);
                    try
                    {
                        for (i = 0; i < serialPort1.ReadBufferSize; i++)
                        {
                            recBuff[i] = Convert.ToByte(serialPort1.ReadByte());
                        }
                    }
                    catch (TimeoutException tExp)
                    {
                        iRecCnt = i;
                    }

                    if (iRecCnt != 0)
                    {
                        // 수신된 바이트 데이터를 유니코드 문자열로 변환
                        strRecData = Encoding.ASCII.GetString(recBuff, 0, iRecCnt);

                        // 수신된 데이터를 ListBox에 표시한다.
                        DelegateRecListAdd(strRecData);
                    }

                    // 스레드를 종료하기위한 검사
                    if (m_Stop == true)
                    {
                        break;
                    }

                    Thread.Sleep(100);
                }

                // 스레드를 종료대기 이밴트 신호보냄               
                m_StopCompletionEvent.Set();


            }
            catch (Exception exp)
            {
                if (m_Stop == true)
                {
                    // serial Port를 접근시 Try~Catch 로 항상 처리한다. 
                    // Open이 안되거나 생성이 안된경우 무조건 예외를 발생할수있다.
                    exp.ToString();
                    m_StopCompletionEvent.Set();
                    return;
                }
            }

        }

        private void SerialPortClose()
        {
            if (serialPort1.IsOpen == false)
            {
                return;
            }

            m_Stop = true;

            serialPort1.ReadTimeout = 300;
                       
            // 수신 스레드가 종료되기를 기다린다.
            Thread.Sleep(1000);

            // 수신 스레드가 종료되었는지 확인
            if (m_StopCompletionEvent.WaitOne((int)1000, false) == true)
            {
                try
                {
                    serialPort1.Close();
                }
                catch (Exception exp)
                {
                    exp.ToString();
                }
                return;
            }
                        
            timerSend.Enabled = false;

            serialPort1.Close();          
        }

        private void butClose_Click(object sender, EventArgs e)
        {
            SerialPortClose();
        }

        private void timerSend_Tick(object sender, EventArgs e)
        {
            if (serialPort1.IsOpen == false)
            {
                timerSend.Enabled = false;
                return;
            }

            try
            {
                byte[] sendBuff = new byte[1024];

                // 입력된 Text를 ASCII 바이트 코드로 전환
                sendBuff = Encoding.ASCII.GetBytes(txtSendData.Text);

                // 데이터 전송
                serialPort1.Write(sendBuff, 0, txtSendData.Text.Length);

                if (chkAutoSend.Checked == false)
                {
                    timerSend.Enabled = false;
                }
            }
            catch (Exception exp)
            {
                // serialPort1의 접근시 Try~Catch 로 항상 처리한다. 
                // Open이 안되거나 생성이 안된경우 무조건 예외를 발생할수있다.
                exp.ToString();
                timerSend.Enabled = false;
                serialPort1.Close();
                m_Stop = true;
            }

        }

        private void butSendStart_Click(object sender, EventArgs e)
        {
            timerSend.Interval = 1000;
            timerSend.Enabled = true;
        }

        private void butSendStop_Click(object sender, EventArgs e)
        {            
            timerSend.Enabled = false;
        }

    }
}