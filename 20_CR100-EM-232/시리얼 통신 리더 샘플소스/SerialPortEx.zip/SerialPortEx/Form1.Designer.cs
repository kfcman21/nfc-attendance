﻿namespace SerialPortEx
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.butExit = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.combStop = new System.Windows.Forms.ComboBox();
            this.txtDataBits = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.combParity = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.combBaudRate = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.radCom3 = new System.Windows.Forms.RadioButton();
            this.radCom2 = new System.Windows.Forms.RadioButton();
            this.radCom1 = new System.Windows.Forms.RadioButton();
            this.recList = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSendData = new System.Windows.Forms.TextBox();
            this.butOpen = new System.Windows.Forms.Button();
            this.butClose = new System.Windows.Forms.Button();
            this.butSendStart = new System.Windows.Forms.Button();
            this.butSendStop = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.timerSend = new System.Windows.Forms.Timer();
            this.chkAutoSend = new System.Windows.Forms.CheckBox();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel2.Controls.Add(this.label4);
            this.panel2.Location = new System.Drawing.Point(14, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(289, 24);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(7, -2);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(413, 27);
            this.label4.Text = "Serial Port Test Program";
            // 
            // butExit
            // 
            this.butExit.Location = new System.Drawing.Point(314, 219);
            this.butExit.Name = "butExit";
            this.butExit.Size = new System.Drawing.Size(133, 46);
            this.butExit.TabIndex = 1;
            this.butExit.Text = "Exit";
            this.butExit.Click += new System.EventHandler(this.butExit_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.combStop);
            this.panel1.Controls.Add(this.txtDataBits);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.combParity);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.combBaudRate);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(314, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(133, 213);
            // 
            // combStop
            // 
            this.combStop.Location = new System.Drawing.Point(8, 184);
            this.combStop.Name = "combStop";
            this.combStop.Size = new System.Drawing.Size(117, 23);
            this.combStop.TabIndex = 10;
            // 
            // txtDataBits
            // 
            this.txtDataBits.Location = new System.Drawing.Point(8, 146);
            this.txtDataBits.Name = "txtDataBits";
            this.txtDataBits.Size = new System.Drawing.Size(117, 23);
            this.txtDataBits.TabIndex = 8;
            this.txtDataBits.Text = "textBox1";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(8, 166);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 19);
            this.label8.Text = "Stop Bit";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(8, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 19);
            this.label7.Text = "Data Bits";
            // 
            // combParity
            // 
            this.combParity.Location = new System.Drawing.Point(8, 108);
            this.combParity.Name = "combParity";
            this.combParity.Size = new System.Drawing.Size(117, 23);
            this.combParity.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(8, 90);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 19);
            this.label6.Text = "Parity";
            // 
            // combBaudRate
            // 
            this.combBaudRate.Location = new System.Drawing.Point(8, 68);
            this.combBaudRate.Name = "combBaudRate";
            this.combBaudRate.Size = new System.Drawing.Size(117, 23);
            this.combBaudRate.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(8, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 19);
            this.label5.Text = "BaudRate";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.radCom3);
            this.panel3.Controls.Add(this.radCom2);
            this.panel3.Controls.Add(this.radCom1);
            this.panel3.Location = new System.Drawing.Point(2, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(126, 51);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 19);
            this.label1.Text = "Port No.";
            // 
            // radCom3
            // 
            this.radCom3.Location = new System.Drawing.Point(6, 34);
            this.radCom3.Name = "radCom3";
            this.radCom3.Size = new System.Drawing.Size(87, 20);
            this.radCom3.TabIndex = 2;
            this.radCom3.Text = "COM3";
            // 
            // radCom2
            // 
            this.radCom2.Location = new System.Drawing.Point(65, 17);
            this.radCom2.Name = "radCom2";
            this.radCom2.Size = new System.Drawing.Size(60, 20);
            this.radCom2.TabIndex = 1;
            this.radCom2.Text = "COM2";
            // 
            // radCom1
            // 
            this.radCom1.Location = new System.Drawing.Point(6, 17);
            this.radCom1.Name = "radCom1";
            this.radCom1.Size = new System.Drawing.Size(87, 20);
            this.radCom1.TabIndex = 0;
            this.radCom1.Text = "COM1";
            // 
            // recList
            // 
            this.recList.Location = new System.Drawing.Point(13, 118);
            this.recList.Name = "recList";
            this.recList.Size = new System.Drawing.Size(289, 98);
            this.recList.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(13, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 22);
            this.label3.Text = "수신 데이터 :";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(13, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(187, 22);
            this.label2.Text = "송신 데이터 :";
            // 
            // txtSendData
            // 
            this.txtSendData.Location = new System.Drawing.Point(14, 69);
            this.txtSendData.Name = "txtSendData";
            this.txtSendData.Size = new System.Drawing.Size(289, 23);
            this.txtSendData.TabIndex = 11;
            this.txtSendData.Text = "textBox1";
            // 
            // butOpen
            // 
            this.butOpen.Location = new System.Drawing.Point(14, 219);
            this.butOpen.Name = "butOpen";
            this.butOpen.Size = new System.Drawing.Size(72, 46);
            this.butOpen.TabIndex = 1;
            this.butOpen.Text = "Open";
            this.butOpen.Click += new System.EventHandler(this.butOpen_Click);
            // 
            // butClose
            // 
            this.butClose.Location = new System.Drawing.Point(86, 219);
            this.butClose.Name = "butClose";
            this.butClose.Size = new System.Drawing.Size(72, 46);
            this.butClose.TabIndex = 1;
            this.butClose.Text = "Close";
            this.butClose.Click += new System.EventHandler(this.butClose_Click);
            // 
            // butSendStart
            // 
            this.butSendStart.Location = new System.Drawing.Point(158, 219);
            this.butSendStart.Name = "butSendStart";
            this.butSendStart.Size = new System.Drawing.Size(72, 46);
            this.butSendStart.TabIndex = 1;
            this.butSendStart.Text = "Send Start";
            this.butSendStart.Click += new System.EventHandler(this.butSendStart_Click);
            // 
            // butSendStop
            // 
            this.butSendStop.Location = new System.Drawing.Point(230, 219);
            this.butSendStop.Name = "butSendStop";
            this.butSendStop.Size = new System.Drawing.Size(72, 46);
            this.butSendStop.TabIndex = 1;
            this.butSendStop.Text = "Send Stop";
            this.butSendStop.Click += new System.EventHandler(this.butSendStop_Click);
            // 
            // timerSend
            // 
            this.timerSend.Tick += new System.EventHandler(this.timerSend_Tick);
            // 
            // chkAutoSend
            // 
            this.chkAutoSend.Location = new System.Drawing.Point(187, 40);
            this.chkAutoSend.Name = "chkAutoSend";
            this.chkAutoSend.Size = new System.Drawing.Size(116, 28);
            this.chkAutoSend.TabIndex = 17;
            this.chkAutoSend.Text = "AutoSend";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(480, 272);
            this.ControlBox = false;
            this.Controls.Add(this.chkAutoSend);
            this.Controls.Add(this.recList);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSendData);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.butClose);
            this.Controls.Add(this.butOpen);
            this.Controls.Add(this.butSendStop);
            this.Controls.Add(this.butSendStart);
            this.Controls.Add(this.butExit);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button butExit;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox recList;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSendData;
        private System.Windows.Forms.Button butOpen;
        private System.Windows.Forms.Button butClose;
        private System.Windows.Forms.Button butSendStart;
        private System.Windows.Forms.Button butSendStop;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radCom3;
        private System.Windows.Forms.RadioButton radCom2;
        private System.Windows.Forms.RadioButton radCom1;
        private System.Windows.Forms.TextBox txtDataBits;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox combParity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox combBaudRate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Timer timerSend;
        private System.Windows.Forms.ComboBox combStop;
        private System.Windows.Forms.CheckBox chkAutoSend;
    }
}

