﻿namespace Serial.NET
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.textBoxDisplay = new System.Windows.Forms.TextBox();
            this.textBoxInput = new System.Windows.Forms.TextBox();
            this.buttonSend = new System.Windows.Forms.Button();
            this.buttonInitaillize = new System.Windows.Forms.Button();
            this.comboBoxComport = new System.Windows.Forms.ComboBox();
            this.comboBoxBaudrate = new System.Windows.Forms.ComboBox();
            this.comboBoxDatabits = new System.Windows.Forms.ComboBox();
            this.comboBoxParity = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxStopbits = new System.Windows.Forms.ComboBox();
            this.labelStatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxDisplay
            // 
            this.textBoxDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.textBoxDisplay.Location = new System.Drawing.Point(8, 10);
            this.textBoxDisplay.MaxLength = 200000;
            this.textBoxDisplay.Multiline = true;
            this.textBoxDisplay.Name = "textBoxDisplay";
            this.textBoxDisplay.ReadOnly = true;
            this.textBoxDisplay.Size = new System.Drawing.Size(393, 335);
            this.textBoxDisplay.TabIndex = 0;
            this.textBoxDisplay.Text = "#################################\r\n\r\nST created by trick14@gmail.com\r\n[2008/08/29" +
                "] Version 0.0.2\r\n\r\n#################################\r\n\r\n";
            // 
            // textBoxInput
            // 
            this.textBoxInput.Location = new System.Drawing.Point(8, 351);
            this.textBoxInput.Name = "textBoxInput";
            this.textBoxInput.Size = new System.Drawing.Size(305, 23);
            this.textBoxInput.TabIndex = 1;
            // 
            // buttonSend
            // 
            this.buttonSend.Location = new System.Drawing.Point(319, 352);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(82, 22);
            this.buttonSend.TabIndex = 2;
            this.buttonSend.Text = "Send";
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // buttonInitaillize
            // 
            this.buttonInitaillize.Location = new System.Drawing.Point(407, 321);
            this.buttonInitaillize.Name = "buttonInitaillize";
            this.buttonInitaillize.Size = new System.Drawing.Size(117, 24);
            this.buttonInitaillize.TabIndex = 3;
            this.buttonInitaillize.Text = "Port Open";
            this.buttonInitaillize.Click += new System.EventHandler(this.buttonInitaillize_Click);
            // 
            // comboBoxComport
            // 
            this.comboBoxComport.Location = new System.Drawing.Point(410, 34);
            this.comboBoxComport.Name = "comboBoxComport";
            this.comboBoxComport.Size = new System.Drawing.Size(114, 23);
            this.comboBoxComport.TabIndex = 4;
            this.comboBoxComport.SelectedIndexChanged += new System.EventHandler(this.comboBoxComport_SelectedIndexChanged);
            // 
            // comboBoxBaudrate
            // 
            this.comboBoxBaudrate.Location = new System.Drawing.Point(410, 98);
            this.comboBoxBaudrate.Name = "comboBoxBaudrate";
            this.comboBoxBaudrate.Size = new System.Drawing.Size(114, 23);
            this.comboBoxBaudrate.TabIndex = 5;
            this.comboBoxBaudrate.SelectedIndexChanged += new System.EventHandler(this.comboBoxBaudrate_SelectedIndexChanged);
            // 
            // comboBoxDatabits
            // 
            this.comboBoxDatabits.Location = new System.Drawing.Point(409, 158);
            this.comboBoxDatabits.Name = "comboBoxDatabits";
            this.comboBoxDatabits.Size = new System.Drawing.Size(115, 23);
            this.comboBoxDatabits.TabIndex = 6;
            this.comboBoxDatabits.SelectedIndexChanged += new System.EventHandler(this.comboBoxDatabits_SelectedIndexChanged);
            // 
            // comboBoxParity
            // 
            this.comboBoxParity.Location = new System.Drawing.Point(410, 220);
            this.comboBoxParity.Name = "comboBoxParity";
            this.comboBoxParity.Size = new System.Drawing.Size(114, 23);
            this.comboBoxParity.TabIndex = 7;
            this.comboBoxParity.SelectedIndexChanged += new System.EventHandler(this.comboBoxParity_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(410, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 21);
            this.label1.Text = "Port";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(410, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 24);
            this.label2.Text = "Baud rate";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(410, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 21);
            this.label3.Text = "Data bits";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(410, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 22);
            this.label4.Text = "Parity";
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(410, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 21);
            this.label5.Text = "Stop Bits";
            // 
            // comboBoxStopbits
            // 
            this.comboBoxStopbits.Location = new System.Drawing.Point(410, 281);
            this.comboBoxStopbits.Name = "comboBoxStopbits";
            this.comboBoxStopbits.Size = new System.Drawing.Size(114, 23);
            this.comboBoxStopbits.TabIndex = 13;
            this.comboBoxStopbits.SelectedIndexChanged += new System.EventHandler(this.comboBoxStopbits_SelectedIndexChanged);
            // 
            // labelStatus
            // 
            this.labelStatus.BackColor = System.Drawing.Color.LightPink;
            this.labelStatus.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular);
            this.labelStatus.Location = new System.Drawing.Point(407, 352);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(117, 22);
            this.labelStatus.Text = "Not Ready";
            this.labelStatus.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(541, 377);
            this.Controls.Add(this.labelStatus);
            this.Controls.Add(this.comboBoxStopbits);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxParity);
            this.Controls.Add(this.comboBoxDatabits);
            this.Controls.Add(this.comboBoxBaudrate);
            this.Controls.Add(this.comboBoxComport);
            this.Controls.Add(this.buttonInitaillize);
            this.Controls.Add(this.buttonSend);
            this.Controls.Add(this.textBoxInput);
            this.Controls.Add(this.textBoxDisplay);
            this.Menu = this.mainMenu1;
            this.Name = "Form1";
            this.Text = "ST v 0.0.2";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxDisplay;
        private System.Windows.Forms.TextBox textBoxInput;
        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.Button buttonInitaillize;
        private System.Windows.Forms.ComboBox comboBoxComport;
        private System.Windows.Forms.ComboBox comboBoxBaudrate;
        private System.Windows.Forms.ComboBox comboBoxDatabits;
        private System.Windows.Forms.ComboBox comboBoxParity;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxStopbits;
        private System.Windows.Forms.Label labelStatus;
    }
}

