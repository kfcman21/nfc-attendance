﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;

namespace Serial.NET
{
    public partial class Form1 : Form
    {
        SerialPort SP = new SerialPort();
        void SP_DataRecieved(Object sender, SerialDataReceivedEventArgs e)
        {
            textBoxDisplay.Text = string.Format("{0}{1}{2}", textBoxDisplay.Text, "\r\n[Received]  ", SP.ReadLine());
        }

        public Form1()
        {
            InitializeComponent();
            SP.DataReceived += new SerialDataReceivedEventHandler(SP_DataRecieved);

            //############################################
            // 콤보 박스 초기화
            //############################################

            textBoxDisplay.ScrollBars = ScrollBars.Vertical;

            // Comport
            comboBoxComport.BeginUpdate();
            foreach (string comport in SerialPort.GetPortNames())
            {
                comboBoxComport.Items.Add(comport);
            }
            comboBoxComport.EndUpdate();

            // Baud Rate
            comboBoxBaudrate.BeginUpdate();
            comboBoxBaudrate.Items.Add("9600 bps");
            comboBoxBaudrate.Items.Add("14400 bps");
            comboBoxBaudrate.Items.Add("19200 bps");
            comboBoxBaudrate.Items.Add("38400 bps");    // default
            comboBoxBaudrate.Items.Add("57600 bps");
            comboBoxBaudrate.Items.Add("115200 bps");
            comboBoxBaudrate.EndUpdate();

            // Data Bits
            comboBoxDatabits.BeginUpdate();
            comboBoxDatabits.Items.Add("8 bits");       // default
            comboBoxDatabits.Items.Add("7 bits");
            comboBoxDatabits.EndUpdate();

            // Parity
            comboBoxParity.BeginUpdate();
            comboBoxParity.Items.Add("EVEN");
            comboBoxParity.Items.Add("MARK");
            comboBoxParity.Items.Add("NONE");           // default
            comboBoxParity.Items.Add("ODD");
            comboBoxParity.Items.Add("SPACE");
            comboBoxParity.EndUpdate();

            // Stop Bits
            comboBoxStopbits.BeginUpdate();
            comboBoxStopbits.Items.Add("NONE");
            comboBoxStopbits.Items.Add("1");            // default
            comboBoxStopbits.Items.Add("1.5");
            comboBoxStopbits.Items.Add("2");
            comboBoxStopbits.EndUpdate();

            // SerialPort의 설정 초기값들
            SP.PortName = "COM1";
            SP.BaudRate = (int)38400;
            SP.DataBits = (int)8;
            SP.Parity = Parity.None;
            SP.StopBits = StopBits.One;
            SP.ReadTimeout = (int)500;
            SP.WriteTimeout = (int)500;
        }

        private void buttonInitaillize_Click(object sender, EventArgs e)
        {   // 포트가 이미 열린경우 닫고, 닫힌 경우 여는 토글버튼.
            if (SP.IsOpen)
            {   // 포트 닫을 때 필요한 작업들.
                SP.Close();
                textBoxDisplay.Text = string.Format("{0}{1}", textBoxDisplay.Text, "\r\n[Succeed] Port Closed");
                labelStatus.Text = "Not Ready";
                labelStatus.BackColor = Color.LightPink;
                buttonInitaillize.Text = "Port Open";
            }
            else
            {
                SP.Open();
                if (SP.IsOpen)
                {   // 포트 열 때 필요한 작업들.
                    textBoxDisplay.Text = string.Format("{0}{1}", textBoxDisplay.Text, "\r\n[Succeed] Port opened");
                    labelStatus.Text = "Port Ready";
                    labelStatus.BackColor = Color.Aquamarine;
                    buttonInitaillize.Text = "Port Close";
                }
                else
                {   // 포트 오픈 실패.
                    textBoxDisplay.Text = string.Format("{0}{1}", textBoxDisplay.Text, "\r\n[Fail] Port not opened");
                }
            }
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            SP.WriteLine(textBoxInput.Text);
            textBoxDisplay.Text = string.Format("{0}{1}{2}", textBoxDisplay.Text, "\r\n[Sent]  ", textBoxInput.Text);
            textBoxInput.Text = "";
            textBoxInput.Focus();
        }

        private void comboBoxComport_SelectedIndexChanged(object sender, EventArgs e)
        {
            SP.PortName = comboBoxComport.SelectedItem.ToString();
        }

        private void comboBoxBaudrate_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxBaudrate.SelectedIndex)
            {
                case 0:
                    SP.BaudRate = (int)9600;
                    break;
                case 1:
                    SP.BaudRate = (int)14400;
                    break;
                case 2:
                    SP.BaudRate = (int)19200;
                    break;
                case 3:
                    SP.BaudRate = (int)38400;
                    break;
                case 4:
                    SP.BaudRate = (int)57600;
                    break;
                case 5:
                    SP.BaudRate = (int)115200;
                    break;
                default:
                    SP.BaudRate = (int)38400;
                    break;
            }
        }

        private void comboBoxDatabits_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxDatabits.SelectedIndex)
            {
                case 0:
                    SP.DataBits = 8;
                    break;
                case 1:
                    SP.DataBits = 7;
                    break;
                default:
                    SP.DataBits = 8;
                    break;
            }
        }

        private void comboBoxParity_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxParity.SelectedIndex)
            {
                case 0:
                    SP.Parity = Parity.Even;
                    break;
                case 1:
                    SP.Parity = Parity.Mark;
                    break;
                case 2:
                    SP.Parity = Parity.None;
                    break;
                case 3:
                    SP.Parity = Parity.Odd;
                    break;
                case 4:
                    SP.Parity = Parity.Space;
                    break;
                default:
                    SP.Parity = Parity.None;
                    break;
            }
        }

        private void comboBoxStopbits_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBoxStopbits.SelectedIndex)
            {
                case 0:
                    SP.StopBits = StopBits.None;
                    break;
                case 1:
                    SP.StopBits = StopBits.One;
                    break;
                case 2:
                    SP.StopBits = StopBits.OnePointFive;
                    break;
                case 3:
                    SP.StopBits = StopBits.Two;
                    break;
                default:
                    SP.StopBits = StopBits.One;
                    break;
            }
        }
    }
}